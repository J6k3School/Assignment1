public interface InterfaceClass {
    void StarterC(String starter);
}
