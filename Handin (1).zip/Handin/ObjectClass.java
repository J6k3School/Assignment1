public class ObjectClass implements InterfaceClass{
    public void StarterC(String starter){
        System.out.println("You chose Bulbasaur");
    }
}